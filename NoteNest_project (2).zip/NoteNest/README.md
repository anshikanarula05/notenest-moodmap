# NoteNest + MoodMap

A local Streamlit app for notes and daily mood check-ins.

## Run on Windows

Open this folder in VS Code, open Terminal, then run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Your notes and mood entries are saved in a local SQLite database (`notenest.db`) in this folder.
