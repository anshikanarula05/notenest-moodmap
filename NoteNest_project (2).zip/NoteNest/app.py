import sqlite3
from datetime import date, datetime, timedelta

import pandas as pd
import plotly.express as px
import streamlit as st

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "notenest.db")

st.set_page_config(page_title="NoteNest + MoodMap", page_icon="🌷", layout="wide")

st.markdown("""
<style>
.stApp { background: linear-gradient(135deg, #fff7fb 0%, #f7f2ff 55%, #fffafd 100%); }
.block-container { padding-top: 1.8rem; max-width: 1200px; }
h1, h2, h3 { color: #6b4c7a; }
div[data-testid="stMetric"] { background: #ffffffb8; border: 1px solid #eadcf4; padding: 14px; border-radius: 16px; }
.stButton > button { border-radius: 12px; border: 1px solid #e4c9ed; }
section[data-testid="stSidebar"] { background: #f6eafa; }
</style>
""", unsafe_allow_html=True)


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            subject TEXT NOT NULL DEFAULT 'General',
            content TEXT NOT NULL DEFAULT '',
            pinned INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS mood_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_date TEXT NOT NULL UNIQUE,
            mood TEXT NOT NULL,
            energy INTEGER NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        )""")


def fetch_notes(search="", subject="All subjects"):
    with connect() as conn:
        query = "SELECT * FROM notes WHERE (title LIKE ? OR content LIKE ?)"
        params = [f"%{search}%", f"%{search}%"]
        if subject != "All subjects":
            query += " AND subject = ?"
            params.append(subject)
        query += " ORDER BY pinned DESC, updated_at DESC"
        return conn.execute(query, params).fetchall()


def get_subjects():
    with connect() as conn:
        rows = conn.execute("SELECT DISTINCT subject FROM notes ORDER BY subject").fetchall()
    return [r["subject"] for r in rows]


def get_moods():
    with connect() as conn:
        return conn.execute("SELECT * FROM mood_entries ORDER BY entry_date DESC").fetchall()


init_db()

with st.sidebar:
    st.markdown("# 🌷 NoteNest")
    st.caption("Your soft little space to think, plan & reflect.")
    page = st.radio("Navigate", ["🏡 Dashboard", "📝 My Notes", "🌦️ MoodMap"])
    st.markdown("---")
    st.caption("Your notes and mood check-ins stay saved locally on this device.")

st.title("NoteNest + MoodMap")
st.caption("A calm space for your notes, study plans, and daily check-ins.")

if page == "🏡 Dashboard":
    notes = fetch_notes()
    moods = get_moods()
    today_entry = next((m for m in moods if m["entry_date"] == date.today().isoformat()), None)
    c1, c2, c3 = st.columns(3)
    c1.metric("📝 Total notes", len(notes))
    c2.metric("📌 Pinned notes", sum(n["pinned"] for n in notes))
    c3.metric("🌈 Mood check-ins", len(moods))
    st.markdown("### A little overview")
    left, right = st.columns(2)
    with left:
        st.subheader("Recently updated notes")
        if notes:
            for n in notes[:5]:
                pin = "📌 " if n["pinned"] else ""
                st.markdown(f"**{pin}{n['title']}**  \n<small>{n['subject']} · Updated {n['updated_at'][:10]}</small>", unsafe_allow_html=True)
                st.write((n["content"][:140] + "…") if len(n["content"]) > 140 else n["content"])
                st.divider()
        else:
            st.info("Your first note is waiting to be created in My Notes.")
    with right:
        st.subheader("Today's MoodMap")
        if today_entry:
            st.success(f"Today's mood: {today_entry['mood']} · Energy: {today_entry['energy']}/5")
            if today_entry["note"]:
                st.write(today_entry["note"])
        else:
            st.write("You haven't checked in today. Visit MoodMap for a quick reflection.")
        st.subheader("Gentle reminder")
        st.write("Small steps count. You don't need to organize your whole life in one day. 💗")

elif page == "📝 My Notes":
    st.subheader("Your notes")
    with st.expander("＋ Create a new note", expanded=not bool(fetch_notes())):
        with st.form("new_note", clear_on_submit=True):
            title = st.text_input("Title", placeholder="e.g. OS Unit 2 revision")
            subject = st.text_input("Subject", value="General", placeholder="College, Ideas, Personal…")
            content = st.text_area("Note", height=150, placeholder="Write anything you want to remember…")
            pinned = st.checkbox("Pin this note")
            submitted = st.form_submit_button("Save note")
            if submitted:
                if not title.strip():
                    st.error("Please add a title.")
                else:
                    now = datetime.now().isoformat(timespec="seconds")
                    with connect() as conn:
                        conn.execute("INSERT INTO notes(title,subject,content,pinned,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                                     (title.strip(), subject.strip() or "General", content.strip(), int(pinned), now, now))
                    st.success("Note saved!")
                    st.rerun()

    search_col, subject_col, export_col = st.columns([2, 1, 1])
    search = search_col.text_input("🔎 Search notes", placeholder="Search title or content")
    subjects = ["All subjects"] + get_subjects()
    subject_filter = subject_col.selectbox("Subject", subjects)
    notes = fetch_notes(search, subject_filter)
    if notes:
        csv_data = pd.DataFrame([dict(n) for n in notes]).to_csv(index=False).encode("utf-8")
        export_col.download_button("Export CSV", csv_data, "notenest_notes.csv", "text/csv")
        for n in notes:
            with st.expander(("📌 " if n["pinned"] else "") + n["title"] + f"  ·  {n['subject']}"):
                with st.form(f"edit_{n['id']}"):
                    e_title = st.text_input("Title", value=n["title"])
                    e_subject = st.text_input("Subject", value=n["subject"])
                    e_content = st.text_area("Note", value=n["content"], height=140)
                    e_pinned = st.checkbox("Pinned", value=bool(n["pinned"]))
                    save_col, delete_col = st.columns(2)
                    save = save_col.form_submit_button("Save changes")
                    delete = delete_col.form_submit_button("Delete note")
                    if save:
                        now = datetime.now().isoformat(timespec="seconds")
                        with connect() as conn:
                            conn.execute("UPDATE notes SET title=?,subject=?,content=?,pinned=?,updated_at=? WHERE id=?",
                                         (e_title.strip() or "Untitled", e_subject.strip() or "General", e_content.strip(), int(e_pinned), now, n["id"]))
                        st.rerun()
                    if delete:
                        with connect() as conn:
                            conn.execute("DELETE FROM notes WHERE id=?", (n["id"],))
                        st.rerun()
    else:
        st.info("No notes match that search yet.")

else:
    st.subheader("🌦️ MoodMap — daily check-in")
    today = date.today().isoformat()
    with connect() as conn:
        existing = conn.execute("SELECT * FROM mood_entries WHERE entry_date=?", (today,)).fetchone()
    st.write("A small check-in can help you notice patterns. There's no right or wrong mood.")
    moods_options = ["😊 Happy", "😌 Calm", "🥰 Excited", "😐 Okay", "😴 Tired", "😟 Anxious", "😔 Sad", "😤 Frustrated"]
    default_mood = existing["mood"] if existing else moods_options[0]
    default_idx = moods_options.index(default_mood) if default_mood in moods_options else 0
    with st.form("mood_form"):
        mood = st.selectbox("How are you feeling today?", moods_options, index=default_idx)
        energy = st.slider("Energy level", 1, 5, int(existing["energy"]) if existing else 3)
        reflection = st.text_area("Journal / reflection", value=existing["note"] if existing else "",
                                  placeholder="What is on your mind today?", height=130)
        save_mood = st.form_submit_button("Save today's check-in")
        if save_mood:
            with connect() as conn:
                conn.execute("""INSERT INTO mood_entries(entry_date,mood,energy,note,created_at)
                    VALUES(?,?,?,?,?) ON CONFLICT(entry_date) DO UPDATE SET
                    mood=excluded.mood, energy=excluded.energy, note=excluded.note, created_at=excluded.created_at""",
                    (today, mood, energy, reflection.strip(), datetime.now().isoformat(timespec="seconds")))
            st.success("Check-in saved. Take care of yourself. 💗")
            st.rerun()

    entries = get_moods()
    if entries:
        st.markdown("### Your last 7 days")
        cutoff = (date.today() - timedelta(days=6)).isoformat()
        recent = [dict(e) for e in entries if e["entry_date"] >= cutoff]
        if recent:
            df = pd.DataFrame(recent).sort_values("entry_date")
            fig = px.line(df, x="entry_date", y="energy", markers=True, range_y=[0, 5],
                          labels={"entry_date": "Date", "energy": "Energy (1–5)"},
                          title="Energy over time")
            fig.update_traces(line_color="#b783d1", marker_color="#e99fbd")
            fig.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(255,255,255,0.65)")
            st.plotly_chart(fig, use_container_width=True)
        st.markdown("### Recent reflections")
        for e in entries[:7]:
            with st.expander(f"{e['entry_date']} · {e['mood']} · Energy {e['energy']}/5"):
                st.write(e["note"] or "No written reflection for this day.")
